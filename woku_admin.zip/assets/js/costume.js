jQuery(document).ready(function($) {
    $('#get_work').click(function(event) {
        console.log("Oke proses");
    });

    $("#waitting").click(function(event) {
        /* Act on the event */
        console.log("oke waitting");
    });
});
