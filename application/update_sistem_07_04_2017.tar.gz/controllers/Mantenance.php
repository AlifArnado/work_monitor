<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mantenance extends CI_Controller {

    public function index()
    {
        $this->load->view('mentenance_view');
    }

}

/* End of file Mantenance.php */
/* Location: ./application/controllers/Mantenance.php */
