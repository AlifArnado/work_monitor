<meta charset="utf-8">
<title>CRM Woku</title>
<meta name="description" content="CRM Woku">
<meta name="author" content="pixelcave">
<meta name="robots" content="noindex, nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<!-- Icons -->
<!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->

<!-- END Icons -->
<link rel="icon" href="<?php echo base_url('assets/images/logo.png'); ?>">
<!-- Stylesheets -->
<!-- Bootstrap is included in its original form, unaltered -->
<link rel="stylesheet" href=" <?php echo base_url('assets/css/bootstrap.min.css'); ?> ">
<!-- Related styles of various icon packs and plugins -->
<link rel="stylesheet" href=" <?php echo base_url('assets/css/plugins.css'); ?> ">
<!-- The main stylesheet of this template. All Bootstrap overwrites are defined in here -->
<link rel="stylesheet" href=" <?php echo base_url('assets/css/main.css'); ?> ">
<!-- Include a specific file here from css/themes/ folder to alter the default theme of the template -->
<!-- The themes stylesheet of this template (for using specific theme color in individual elements - must included last) -->
<link rel="stylesheet" href=" <?php echo base_url('assets/css/themes.css'); ?> ">

<link rel="stylesheet" href="<?php echo base_url('assets/datepicker/css/datepicker.css'); ?>">

<!-- include sweet alert -->
<link rel="stylesheet" href="<?php echo base_url('assets/node_modules/sweetalert/dist/sweetalert.css'); ?> ">

<script type="text/javascript" src="<?php echo base_url('assets/ckeditor/ckeditor.js'); ?>"></script>
<!-- END Stylesheets -->
<!-- Modernizr (browser feature detection library) -->
<script src="<?php echo base_url('assets/js/vendor/modernizr.min.js'); ?> "></script>
<?php
date_default_timezone_set("Asia/Jakarta");
 ?>
